 
package cyber.management.system;

 
public class CyberManagementSystem {

    
    public static void main(String[] args) {
         
    }
    
}
